import React, { Component } from "react";
import TextLoop from "react-text-loop";
import PathFindingVisualizer from "./PathFindingVisualizer/PathFindingVisualizer";
import SortingVisualizer from "./SortingVisualizer/SortingVisualizer";
import "./Visualizer.css";
import AIVisualizer from "./AIVisualizer/AIVisualizer";

export default class Visualizer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mode: "main",
      rendering: false,
      algorithms: [],
      currentAlgorithm: null,
      goFunction: () => {},
      resetFunction: () => {},
      setAlgorithm: () => {},
      sortingClicked: false,
      pathClicked: false,
      AIClicked: false,
      aicount: 0,
    };
    this.getFunctions = this.getFunctions.bind(this);
    this.changeRenderingState = this.changeRenderingState.bind(this);
  }

  changeRenderingState(rendering) {
    this.setState({ rendering: rendering });
  }

  getFunctions(go, reset, setAlgo, algorithms) {
    this.state.goFunction = go;
    this.state.resetFunction = reset;
    this.state.setAlgorithm = setAlgo;
    this.state.algorithms = algorithms;
    this.setState({ algorithms: algorithms });
  }

  render() {
    let renderObj = null;
    if (this.state.mode === "pathfinding") {
      renderObj = (
        <PathFindingVisualizer
          setVisualizerRendering={this.changeRenderingState}
          getFunctions={this.getFunctions}
        />
      );
    } else if (this.state.mode === "sorting") {
      renderObj = (
        <SortingVisualizer
          setVisualizerRendering={this.changeRenderingState}
          getFunctions={this.getFunctions}
        />
      );
    } else if (this.state.mode === "ai") {
      renderObj = (
        <AIVisualizer
          count={this.state.aicount}
          setVisualizerRendering={this.changeRenderingState}
          getFunctions={this.getFunctions}
        ></AIVisualizer>
      );
    } else {
      renderObj = (
        <div class="welbotron">
          <div class="container welc">
            <h1 class="welcome">
              Hello, algorithms.
              <p class="lead mt-4">
                This website might help you understand algorithms better by
                visualizing them.
              </p>
              <p class="secondline lead">
                Click on one of the categories below to visualize algorithms.
              </p>
            </h1>
            <a
              href="#"
              class="mainpage-b"
              onClick={() => {
                if (!this.state.rendering) {
                  this.setState({ mode: "pathfinding" });
                  this.setState({ currentAlgorithm: null, pathClicked: true });
                }
              }}
              data-toggle={this.state.pathClicked ? "" : "modal"}
              data-target="#pathIntroModal"
            >
              <span></span>
              PATH FINDING
            </a>
            <a
              href="#"
              class="mainpage-b"
              onClick={() => {
                if (!this.state.rendering) {
                  this.setState({
                    mode: "sorting",
                    currentAlgorithm: null,
                    sortingClicked: true,
                  });
                }
              }}
              data-toggle={this.state.sortingClicked ? "" : "modal"}
              data-target="#sortingIntroModal"
            >
              <span></span>
              SORTING
            </a>
          </div>
        </div>
      );
    }
    let invisibleOrNot = "";
    if (this.state.mode === "main") invisibleOrNot = " invisible";
    let algorithms = this.state.algorithms;
    return (
      <>
        <nav
          class="navbar navbar-expand-lg navbar-light fixed-top bg-dark"
          style={{
            display: "flex",
            justifyContent: "space-between",
            flexWrap: "nowrap",
            width: "100vw",
            fontFamily: `-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji"`,
          }}
        >
          <button
            onClick={() => {
              if (!this.state.rendering) {
                this.setState({ mode: "main" });
              }
            }}
            type="button"
            class="btn btn-dark navbtn"
            disabled={this.state.rendering}
          >
            Main
          </button>

          <button
            onClick={() => {
              if (!this.state.rendering) {
                this.setState({
                  mode: "pathfinding",
                  currentAlgorithm: null,
                  pathClicked: true,
                });
                this.state.setAlgorithm(-1);
              }
            }}
            type="button"
            class="btn btn-dark navbtn"
            data-toggle={this.state.pathClicked ? "" : "modal"}
            data-target="#pathIntroModal"
            disabled={this.state.rendering}
          >
            Pathfinding
          </button>

          <button
            onClick={() => {
              if (!this.state.rendering) {
                this.setState({
                  mode: "sorting",
                  currentAlgorithm: null,
                  sortingClicked: true,
                });
                this.state.setAlgorithm(-1);
              }
            }}
            type="button"
            class="btn btn-dark navbtn"
            data-toggle={this.state.sortingClicked ? "" : "modal"}
            data-target="#sortingIntroModal"
            disabled={this.state.rendering}
          >
            Sorting
          </button>

          <div class={"dropdown" + invisibleOrNot}>
            <button
              class="btn btn-secondary dropdown-toggle navbtn"
              type="button"
              id="dropdownMenuButton"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
              disabled={this.state.rendering}
            >
              {this.state.currentAlgorithm == null
                ? "Algorithms"
                : this.state.currentAlgorithm}
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <li>
                {algorithms.map((algorithm, algoId) => {
                  return (
                    <button
                      type="button"
                      class="btn btn-light navbtn"
                      onClick={() => {
                        this.state.setAlgorithm(algoId);
                        this.setState({
                          currentAlgorithm: this.state.algorithms[algoId],
                        });
                      }}
                    >
                      {algorithm}
                    </button>
                  );
                })}
              </li>
            </div>
          </div>

          <div class={"dropdown" + invisibleOrNot}>
            <button
              class="btn btn-light dropdown-toggle navbtn"
              type="button"
              id="dropdownMenuButton"
              data-toggle="dropdown"
              aria-haspopup="true"
              aria-expanded="false"
              disabled={this.state.rendering}
            >
              Actions
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <li>
                <button
                  type="button"
                  class="btn btn-light navbtn"
                  onClick={() => this.state.goFunction()}
                  data-toggle={
                    this.state.currentAlgorithm === null ? "modal" : ""
                  }
                  data-target="#setAlgoModal"
                  disabled={
                    this.state.mode === "ai" &&
                    this.state.currentAlgorithm === "Minimax"
                  }
                >
                  Go!
                </button>
                <button
                  type="button"
                  class="btn btn-light navbtn"
                  onClick={() => this.state.resetFunction()}
                >
                  Reset
                </button>
              </li>
            </div>
          </div>

          <a
            href="https://github.com/boidushya/algo-visualizer"
            target="_blank"
            rel="noopener noreferrer"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              style={{
                opacity: "0.7 !important",
                color: "white",
                fill: "currentColor",
              }}
            >
              <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M12.026 2c-5.509 0-9.974 4.465-9.974 9.974 0 4.406 2.857 8.145 6.821 9.465.499.09.679-.217.679-.481 0-.237-.008-.865-.011-1.696-2.775.602-3.361-1.338-3.361-1.338-.452-1.152-1.107-1.459-1.107-1.459-.905-.619.069-.605.069-.605 1.002.07 1.527 1.028 1.527 1.028.89 1.524 2.336 1.084 2.902.829.091-.645.351-1.085.635-1.334-2.214-.251-4.542-1.107-4.542-4.93 0-1.087.389-1.979 1.024-2.675-.101-.253-.446-1.268.099-2.64 0 0 .837-.269 2.742 1.021a9.582 9.582 0 0 1 2.496-.336 9.554 9.554 0 0 1 2.496.336c1.906-1.291 2.742-1.021 2.742-1.021.545 1.372.203 2.387.099 2.64.64.696 1.024 1.587 1.024 2.675 0 3.833-2.33 4.675-4.552 4.922.355.308.675.916.675 1.846 0 1.334-.012 2.41-.012 2.737 0 .267.178.577.687.479C19.146 20.115 22 16.379 22 11.974 22 6.465 17.535 2 12.026 2z"
              ></path>
            </svg>
            {/* <img
              class="githubimg"
              src="
              width="40px"
              height="40px"
              style={{ opacity: "0.7 !important" }}
              alt
            ></img> */}
          </a>
        </nav>

        <div class="modal fade" id="setAlgoModal" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">No Algorithm Selected</h5>
                <button type="button" class="close" data-dismiss="modal">
                  &times;
                </button>
              </div>

              <div class="modal-body-alert">
                <p>Please select an algorithm first.</p>
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-dark"
                  data-dismiss="modal"
                  style={{ width: "100px" }}
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="modal fade" id="pathIntroModal" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content intro">
              <div class="modal-header">
                <h5 class="modal-title">Pathfinding</h5>
                <button type="button" class="close" data-dismiss="modal">
                  &times;
                </button>
              </div>

              <div class="modal-body intro">
                <p>
                  Pathfinding is generally the process of finding a route
                  between two points. It is closely related to the shortest path
                  problem in graph theory, which examines how to identify the
                  "best" paths valued by different criteria (Ex. distance, cost,
                  time consumption).
                </p>
                <p>
                  Pathfinding is also similar to Searching in some
                  circumstances. For instance, we can use [breadth-first search]
                  to find the shortest path in a grid world.
                </p>
                <p>
                  In our scenario, the paths are valued by the number of cells
                  they passed from START:
                  <div class="simg" width="20" height="20"></div>
                  to the TARGET:
                  <div class="fimg" width="20" height="20"></div>.
                </p>
                <p>
                  You may drag the START and TARGET icons to change their
                  positions, and click on the blank nodes to add Walls.
                </p>

                <p>Now please choose a sorting algorithm and visualize it!</p>
                <p class="tips">
                  (after choosing an algorithm, click on the [Actions] button.)
                </p>
                <br />
                <p class="tips">
                  Note: there could be multiple "best" paths, so paths generated
                  by different algorithms may not be consistent.
                </p>
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-dark"
                  data-dismiss="modal"
                  style={{ width: "100px" }}
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="modal fade" id="sortingIntroModal" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content intro">
              <div class="modal-header">
                <h5 class="modal-title">Sorting</h5>
                <button type="button" class="close" data-dismiss="modal">
                  &times;
                </button>
              </div>

              <div class="modal-body intro">
                <p>
                  Sorting is a process of arranging an ordered sequence. It is a
                  common operation in many applications.
                </p>
                <p>
                  Common uses of sorted sequences are:
                  <div class="uses-list">
                    <p>·lookup or search efficiently</p>
                    <p>·merge sequences efficiently</p>
                    <p>·process data in a defined order</p>
                  </div>
                  Now please choose a sorting algorithm and visualize it!
                </p>
                <p class="tips">
                  (after choosing an algorithm, click on the [Actions] button.)
                </p>
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-dark"
                  data-dismiss="modal"
                  style={{ width: "100px" }}
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>

        <div class="modal fade " id="aiIntroModal" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content intro">
              <div class="modal-header">
                <h5 class="modal-title">Artificial Intelligence</h5>
                <button type="button" class="close" data-dismiss="modal">
                  &times;
                </button>
              </div>

              <div class="modal-body intro">
                <p>
                  Artificial intelligence (AI) is intelligence demonstrated by
                  machines. Leading textbooks define the field as the study of
                  "intelligent agents": any device that perceives its
                  environment and takes actions that maximize its chance of
                  successfully achieving its goals.
                </p>
                <p>
                  In this category, you will experience with powerful AI
                  algorithms based on fundamental ideas. Please try to
                  understand those ideas behind through the visualizations, and
                  I would try my best to demonstrate those principles.
                </p>
                <p> Now please choose an algorithm and begin your journey!</p>
              </div>
              <div class="modal-footer">
                <button
                  type="button"
                  class="btn btn-dark"
                  data-dismiss="modal"
                  style={{ width: "100px" }}
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>

        <div>{renderObj}</div>
      </>
    );
  }
}
