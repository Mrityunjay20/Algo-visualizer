# algo-visualizer
This project consisits of path finder algorithms and sorting algorithms
